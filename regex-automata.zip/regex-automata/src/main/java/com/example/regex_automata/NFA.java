package com.example.regex_automata;

import java.util.ArrayList;
import java.util.List;

public class NFA {

    State start;
    State end;
    List<Transition> transitions = new ArrayList<>();

    public State getStart() {
        return start;
    }

    public State getEnd() {
        return end;
    }

    public List<Transition> getTransitions() {
        return transitions;
    }
}