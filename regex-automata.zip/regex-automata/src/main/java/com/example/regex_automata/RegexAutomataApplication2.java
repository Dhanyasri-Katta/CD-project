package com.example.regex_automata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegexAutomataApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(RegexAutomataApplication2.class, args);
	}

}
	