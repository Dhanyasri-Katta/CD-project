package com.example.regex_automata;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegexController {

    @PostMapping("/convert")
    public NFA convertRegex(@RequestBody RegexRequest request) {

        String regex = request.getRegex();

        return ThompsonConstruction.convertToNFA(regex);
    }
}