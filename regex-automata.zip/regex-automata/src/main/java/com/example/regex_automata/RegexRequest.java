package com.example.regex_automata;

public class RegexRequest {

    private String regex;

    public RegexRequest() {
    }

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }
}