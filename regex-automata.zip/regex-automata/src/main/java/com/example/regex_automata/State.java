package com.example.regex_automata;

public class State {

    int id;

    State(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}