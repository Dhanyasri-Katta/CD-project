package com.example.regex_automata;

import java.util.Stack;

public class ThompsonConstruction {

    static int stateCount = 0;
   
    static State newState() {
        return new State(stateCount++);
    }

    static NFA symbol(char symbol) {

        State start = newState();
        State end = newState();

        NFA nfa = new NFA();
        nfa.start = start;
        nfa.end = end;

        nfa.transitions.add(
            new Transition(start, end, String.valueOf(symbol))
        );

        return nfa;
    }

    
    static NFA concatenate(NFA first, NFA second) {

        NFA result = new NFA();

        result.start = first.start;
        result.end = second.end;

        result.transitions.addAll(first.transitions);

        
        result.transitions.add(
            new Transition(first.end, second.start, "ε")
        );

        result.transitions.addAll(second.transitions);

        return result;
    }

    
    static NFA union(NFA first, NFA second) {

        State start = newState();
        State end = newState();

        NFA result = new NFA();

        result.start = start;
        result.end = end;

        result.transitions.add(
            new Transition(start, first.start, "ε")
        );

        result.transitions.add(
            new Transition(start, second.start, "ε")
        );

        result.transitions.addAll(first.transitions);
        result.transitions.addAll(second.transitions);

        result.transitions.add(
            new Transition(first.end, end, "ε")
        );

        result.transitions.add(
            new Transition(second.end, end, "ε")
        );

        return result;
    }

    
    static NFA star(NFA nfa) {

        State start = newState();
        State end = newState();

        NFA result = new NFA();

        result.start = start;
        result.end = end;

        
        result.transitions.add(
            new Transition(start, end, "ε")
        );

       
        result.transitions.add(
            new Transition(start, nfa.start, "ε")
        );

      
        result.transitions.addAll(nfa.transitions);

        result.transitions.add(
            new Transition(nfa.end, nfa.start, "ε")
        );

     
        result.transitions.add(
            new Transition(nfa.end, end, "ε")
        );

        return result;
    }

    static boolean isOperator(char c) {
        return c == '+' || c == '.' || c == '*';
    }


    static String addConcatenation(String regex) {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < regex.length(); i++) {

            char current = regex.charAt(i);

            result.append(current);

            if (i + 1 < regex.length()) {

                char next = regex.charAt(i + 1);

                if ((Character.isLetterOrDigit(current)
                        || current == ')'
                        || current == '*')
                        &&
                    (Character.isLetterOrDigit(next)
                        || next == '(')) {

                    result.append('.');
                }
            }
        }

        return result.toString();
    }

    static int precedence(char operator) {

        if (operator == '*') {
            return 3;
        }

        if (operator == '.') {
            return 2;
        }

        if (operator == '+') {
            return 1;
        }

        return 0;
    }

    static String toPostfix(String regex) {

        StringBuilder postfix = new StringBuilder();

        Stack<Character> operators = new Stack<>();

        for (int i = 0; i < regex.length(); i++) {

            char c = regex.charAt(i);

            if (Character.isLetterOrDigit(c)) {

                postfix.append(c);

            } else if (c == '(') {

                operators.push(c);

            } else if (c == ')') {

                while (!operators.isEmpty()
                        && operators.peek() != '(') {

                    postfix.append(operators.pop());
                }

                if (!operators.isEmpty()
                        && operators.peek() == '(') {

                    operators.pop();
                }

            } else if (isOperator(c)) {

                while (!operators.isEmpty()
                        && operators.peek() != '('
                        && precedence(operators.peek())
                           >= precedence(c)) {

                    postfix.append(operators.pop());
                }

                operators.push(c);
            }
        }

        while (!operators.isEmpty()) {
            postfix.append(operators.pop());
        }

        return postfix.toString();
    }

    static NFA buildNFA(String postfix) {

        Stack<NFA> stack = new Stack<>();

        for (int i = 0; i < postfix.length(); i++) {

            char c = postfix.charAt(i);

            if (Character.isLetterOrDigit(c)) {

                stack.push(symbol(c));

            } else if (c == '.') {

                NFA second = stack.pop();
                NFA first = stack.pop();

                stack.push(
                    concatenate(first, second)
                );

            } else if (c == '+') {

                NFA second = stack.pop();
                NFA first = stack.pop();

                stack.push(
                    union(first, second)
                );

            } else if (c == '*') {

                NFA nfa = stack.pop();

                stack.push(
                    star(nfa)
                );
            }
        }
        
        return stack.pop();
    }

    static NFA convertToNFA(String regex) {

        stateCount = 0;

        regex = regex.replaceAll("\\s+", "");

        String withConcatenation =
            addConcatenation(regex);

        String postfix =
            toPostfix(withConcatenation);

        return buildNFA(postfix);
    }
}