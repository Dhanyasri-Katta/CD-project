package com.example.regex_automata;

public class Transition {

    State from;
    State to;
    String symbol;

    Transition(State from, State to, String symbol) {
        this.from = from;
        this.to = to;
        this.symbol = symbol;
    }

    public State getFrom() {
        return from;
    }

    public State getTo() {
        return to;
    }

    public String getSymbol() {
        return symbol;
    }
}