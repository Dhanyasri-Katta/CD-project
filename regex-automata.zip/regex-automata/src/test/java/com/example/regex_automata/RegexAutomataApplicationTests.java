package com.example.regex_automata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegexAutomataApplicationTests {

	@Test
	void contextLoads() {
	}

}
